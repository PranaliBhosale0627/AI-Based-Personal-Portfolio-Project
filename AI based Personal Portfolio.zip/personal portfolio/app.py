from flask import Flask, render_template, request, redirect, url_for, session, flash,make_response
from datetime import datetime
import sqlite3
import os
import pdfkit

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'portfolio.db'


from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'static/uploads/profile_images'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Initialize DB
def init_db():
    with sqlite3.connect(DATABASE) as conn:
        c = conn.cursor()

        # Users table
        c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')

        # Profiles table
        c.execute('''
            CREATE TABLE IF NOT EXISTS profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE,
                full_name TEXT,
                email TEXT,
                phone TEXT,
                linkedin TEXT,
                github TEXT,
                job_title TEXT,
                summary TEXT,
                skills TEXT,
                education TEXT,
                experience TEXT,
                profile_image TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        ''')

        # Templates table ✅ ADD THIS:
        c.execute('''
                CREATE TABLE IF NOT EXISTS templates (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER NOT NULL,
                  title TEXT NOT NULL,
                  file TEXT NOT NULL,
                  date_created TEXT,
                  FOREIGN KEY(user_id) REFERENCES users(id)
                )
        ''')


        # Messages table
        c.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT,
                message TEXT
            )
        ''')

        conn.commit()


@app.route('/')
def default():
    return redirect(url_for('login'))

# --- Registration ---
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email').lower()
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if password != confirm_password:
            # flash("Passwords do not match!", "danger")
            return redirect(url_for('register'))  # FIXED HERE

        try:
            with sqlite3.connect(DATABASE) as conn:
                c = conn.cursor()
                c.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
                          (name, email, password))
                conn.commit()
                # flash("Registration successful. Please log in.", "success")
                return redirect(url_for('login'))  # REDIRECT TO LOGIN
        except sqlite3.IntegrityError:
            # flash("Email already exists. Try a different one.", "danger")
            return redirect(url_for('register'))  # ADD THIS TOO

    return render_template('auth/register.html')

# --- Login ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email').lower()
        password = request.form.get('password')
        
        with sqlite3.connect(DATABASE) as conn:
            c = conn.cursor()
            c.execute("SELECT id, name, password FROM users WHERE email = ?", (email,))
            user = c.fetchone()

            if user and user[2] == password:
                session['user_id'] = user[0]
                session['name'] = user[1]
                # flash("Login successful!", "success")
                return redirect(url_for('home'))
            else:
                print(f"No User exists")
                # flash("Invalid email or password.", "danger")

    return render_template('auth/login.html')

# --- Dashboard ---
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
       return redirect(url_for('login'))
    return render_template('profile/dashboard.html', name=session.get('name'))
#---------------home---------#
@app.route('/home')
def home():
    return render_template('profile/home.html')

# --- Logout ---
@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for('login'))

@app.route('/about')
def about():
    return render_template('profile/about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        with sqlite3.connect(DATABASE) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)", (name, email, message))
            conn.commit()

        flash("Message sent successfully! Thank you for contacting us.", "success")
        return redirect(url_for('home'))

    return render_template('profile/contact.html')


# from werkzeug.utils import secure_filename

# UPLOAD_FOLDER = 'static/uploads/profile_images'
# os.makedirs(UPLOAD_FOLDER, exist_ok=True)
# app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# def allowed_file(filename):
#     return '.' in filename and \
#            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/download_resume/<template>')
def download_resume(template):
    if 'user_id' not in session:
        flash("Please login to download the resume.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    with sqlite3.connect(DATABASE) as conn:
        c = conn.cursor()

        # Get user profile
        c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
        row = c.fetchone()

        if not row:
            flash("Please create your profile before downloading the resume.", "danger")
            return redirect(url_for('create_profile'))

        # ✅ Extract columns BEFORE running any other query
        columns = [desc[0] for desc in c.description]
        profile = dict(zip(columns, row))

        # ✅ Save template usage if not already saved
        c.execute("SELECT * FROM templates WHERE user_id = ? AND file = ?", (user_id, template))
        if not c.fetchone():
            c.execute('''
                INSERT INTO templates (user_id, title, file, date_created)
                VALUES (?, ?, ?, ?)
            ''', (user_id, template.replace('_', ' ').title(), template, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            conn.commit()
            print("✅ Template saved from download:", template)

    # Render template to HTML
    html = render_template(f'auth/template/{template}.html', profile=profile)

    # Generate PDF
    config = pdfkit.configuration(wkhtmltopdf=r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe')
    pdf = pdfkit.from_string(html, False, configuration=config)

    # Send as response
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename={template}_resume.pdf'
    return response



@app.route('/create_profile', methods=['GET', 'POST'])
def create_profile():
    if 'user_id' not in session:
        flash("Please login to create your profile.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        user_id = session['user_id']
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        linkedin = request.form.get('linkedin')
        github = request.form.get('github')
        job_title = request.form.get('job_title')
        summary = request.form.get('summary')
        skills = request.form.get('skills')
        education_raw = request.form.get('education')
        experience_raw = request.form.get('experience')
        education_cleaned = '|'.join([e.strip() for e in education_raw.split(',') if e.strip()])
        experience_cleaned = '|'.join([e.strip() for e in experience_raw.split(',') if e.strip()])


        # Handle profile image upload
        file = request.files.get('profile_image')
        profile_image_filename = None
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            profile_image_filename = f"{user_id}_{filename}"
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], profile_image_filename))

        try:
            with sqlite3.connect(DATABASE) as conn:
                c = conn.cursor()

                # Check if profile already exists for user
                c.execute("SELECT id FROM profiles WHERE user_id = ?", (user_id,))
                existing = c.fetchone()

                if existing:
                    # Update existing profile
                    c.execute('''
                        UPDATE profiles SET
                            full_name = ?, email = ?, phone = ?, linkedin = ?, github = ?,
                            job_title = ?, summary = ?, skills = ?, education = ?, experience = ?,
                            profile_image = COALESCE(?, profile_image)
                        WHERE user_id = ?
                    ''', (full_name, email, phone, linkedin, github, job_title, summary, skills, education_cleaned, experience_cleaned, profile_image_filename, user_id))
                else:
                    # Insert new profile
                    c.execute('''
                        INSERT INTO profiles (
                            user_id, full_name, email, phone, linkedin, github,
                            job_title, summary, skills, education, experience, profile_image
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (user_id, full_name, email, phone, linkedin, github, job_title, summary, skills, education_cleaned, experience_cleaned, profile_image_filename))

                conn.commit()
            flash("Profile saved successfully!", "success")
            # return redirect(url_for('dashboard'))
        except Exception as e:
            print("Error saving profile:", e)
            flash("An error occurred while saving your profile.", "danger")
            return redirect(url_for('create_profile'))

    return render_template('profile/create_profile.html')

@app.route('/update_profile', methods=['GET', 'POST'])
def update_profile():
    if 'user_id' not in session:
        flash("Please login to update your profile.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    if request.method == 'POST':
        # Similar to create_profile POST logic...
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        linkedin = request.form.get('linkedin')
        github = request.form.get('github')
        job_title = request.form.get('job_title')
        summary = request.form.get('summary')
        skills = request.form.get('skills')
        education_raw = request.form.get('education')
        experience_raw = request.form.get('experience')
        education_cleaned = '|'.join([e.strip() for e in education_raw.split(',') if e.strip()])
        experience_cleaned = '|'.join([e.strip() for e in experience_raw.split(',') if e.strip()])

        file = request.files.get('profile_image')
        profile_image_filename = None
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            profile_image_filename = f"{user_id}_{filename}"
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], profile_image_filename))

        try:
            with sqlite3.connect(DATABASE) as conn:
                c = conn.cursor()
                c.execute('''
                    UPDATE profiles SET
                        full_name = ?, email = ?, phone = ?, linkedin = ?, github = ?,
                        job_title = ?, summary = ?, skills = ?, education = ?, experience = ?,
                        profile_image = COALESCE(?, profile_image)
                    WHERE user_id = ?
                ''', (full_name, email, phone, linkedin, github, job_title, summary, skills, education_cleaned, experience_cleaned, profile_image_filename, user_id))
                conn.commit()
            flash("Profile updated successfully!", "success")
            # return redirect(url_for('dashboard'))
        except Exception as e:
            print("Error updating profile:", e)
            flash("An error occurred while updating your profile.", "danger")
            return redirect(url_for('update_profile'))

    # For GET: fetch the existing profile data
    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row  # Enable dict-style access
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()
            if not profile:
                flash("No profile found to update. Please create one first.", "warning")
                return redirect(url_for('create_profile'))
    except Exception as e:
        print("Error fetching profile for update:", e)
        flash("Could not load profile data.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('profile/update_profile.html', profile=profile)

#------------view profile--------
@app.route('/view_profile')
def view_profile():
    if 'user_id' not in session:
        flash("Please login first.", "warning")
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    with sqlite3.connect(DATABASE) as conn:
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
        profile = c.fetchone()
        if not profile:
            flash("No profile found. Please create one.", "info")
            return redirect(url_for('create_profile'))
    return render_template('profile/view_profile.html', profile=profile)

#--------your_templates---------

@app.route('/your_templates')
def your_templates():
    if 'user_id' not in session:
        flash("Please log in first.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    with sqlite3.connect(DATABASE) as conn:
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT id, title, file, date_created FROM templates WHERE user_id = ?", (user_id,))
        templates = c.fetchall()

    return render_template('profile/your_templates.html', templates=templates)


@app.route('/view_template/<template_name>')
def view_template(template_name):
    if 'user_id' not in session:
        flash("Please login to view your template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()

            # ✅ Save if not already saved
            c.execute("SELECT * FROM templates WHERE user_id = ? AND file = ?", (user_id, template_name))
            if not c.fetchone():
                c.execute('''
                    INSERT INTO templates (user_id, title, file, date_created)
                    VALUES (?, ?, ?, ?)
                ''', (
                    user_id,
                    template_name.replace('_', ' ').title(),
                    template_name,
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                ))
                conn.commit()
                print("✅ Template saved to DB:", template_name)

            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            row = c.fetchone()

        if not row:
            flash("Please create your profile first.", "info")
            return redirect(url_for('create_profile'))

        profile = dict(row)

        return render_template(
            f'auth/template/{template_name}.html',
            content=profile,
            image=profile.get('profile_image'),
            title=template_name.replace('_', ' ').title()
        )

    except Exception as e:
        print("❌ Error loading template:", e)
        flash("Something went wrong.", "danger")
    return redirect(url_for('dashboard'))


    
@app.route('/delete_template/<int:template_id>', methods=['GET'])
def delete_template(template_id):
    if 'user_id' not in session:
        flash("Please login to delete a template.", "warning")
        return redirect(url_for('login'))

    try:
        user_id = session['user_id']
        with sqlite3.connect(DATABASE) as conn:
            c = conn.cursor()
            # Assuming templates are stored with user_id and template_id (filename or db id)
            c.execute("DELETE FROM templates WHERE user_id = ? AND id = ?", (user_id, template_id))
            conn.commit()

        flash("Template deleted successfully.", "success")
    except Exception as e:
        print("Error deleting template:", e)
        flash("Error occurred while deleting template.", "danger")

    return redirect(url_for('your_templates'))




# --- Role-specific Routes ---

#-----------content creator----------
@app.route('/template/content_creator')
def content_creator():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/content_creator.html', profile=profile)

#---------fullstack developer---------

@app.route('/template/fullstack_developer')
def fullstack_developer():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/fullstack_developer.html', profile=profile)


#----------graphic designer----------

@app.route('/template/graphic_designer')
def graphic_designer():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/graphic_designer.html', profile=profile)

#---------------data scientist----------

@app.route('/template/data_scientist')
def data_scientist():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/data_scientist.html', profile=profile)

#------------digital marketer----------

@app.route('/template/digital_marketer')
def digital_marketer():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/digital_marketer.html', profile=profile)

#--------modern minimalist--------- 

@app.route('/template/modern_minimalist')
def modern_minimalist():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/modern_minimalist.html', profile=profile)

#-------product manager---------

@app.route('/template/product_manager')
def product_manager():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/product_manager.html', profile=profile)

#----------professional developer---------

@app.route('/template/professional_developer')
def professional_developer():
    if 'user_id' not in session:
        flash("Please login to access the template.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']

    try:
        with sqlite3.connect(DATABASE) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
            profile = c.fetchone()

            if not profile:
                flash("No profile found. Please create your profile first.", "info")
                return redirect(url_for('create_profile'))

    except Exception as e:
        print("Error fetching profile:", e)
        flash("Something went wrong while fetching your profile.", "danger")
        return redirect(url_for('dashboard'))

    return render_template('auth/template/professional_developer.html', profile=profile)

if __name__ == '__main__':
    init_db() 
    app.run(debug=True)                  




